import pyautogui
pyautogui.position()