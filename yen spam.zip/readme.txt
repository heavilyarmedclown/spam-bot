requires the pyautogui library

the position file is for checking your current mouse X and Y coords for tweaking

The upload image file its going to have to be tweaked for wherever you have the image stored on your computer. It will click on the media button on the yen post, bringing up your file explorer.  

the spam bot can obviously be edited to say whatever you want. But would need its positioning tweaked to work with comments.
