import pyautogui

pyautogui.moveTo(788, 700, duration=0.5) #move to comment box 1st
pyautogui.click(clicks=1, interval=0, button='left') #select comment box
pyautogui.typewrite('Mysterium Coin, Good Investment?', interval=0.1) #spam
pyautogui.moveTo(1218, 711, duration=0.5) #move to send
pyautogui.click(clicks=1, interval=0, button='left') #send button

pyautogui.moveTo(747, 654, duration=0.5) #move to comment box 2nd
pyautogui.click(clicks=1, interval=0, button='left') #select comment box
pyautogui.typewrite('xrparmy', interval=0.1) #spam
pyautogui.moveTo(1207, 664, duration=0.5) #move to send
pyautogui.click(clicks=1, interval=0, button='left') #send button

pyautogui.moveTo(758, 616, duration=0.5) #move to comment box 3rd
pyautogui.click(clicks=1, interval=0, button='left') #select comment box
pyautogui.typewrite('wen lambo', interval=0.1) #spam
pyautogui.moveTo(1207, 616, duration=0.5) #move to send
pyautogui.click(clicks=1, interval=0, button='left') #send button

pyautogui.moveTo(758, 584, duration=0.5) #move to comment box 4th
pyautogui.click(clicks=1, interval=0, button='left') #select comment box
pyautogui.typewrite('electroneum is good', interval=0.1) #spam
pyautogui.moveTo(1223, 584, duration=0.5) #move to send
pyautogui.click(clicks=1, interval=0, button='left') #send button

pyautogui.moveTo(758, 538, duration=0.5) #move to comment box 5th
pyautogui.click(clicks=1, interval=0, button='left') #select comment box
pyautogui.typewrite('Doge to the Moon', interval=0.1) #spam
pyautogui.moveTo(1223, 538, duration=0.5) #move to send
pyautogui.click(clicks=1, interval=0, button='left') #send button

pyautogui.moveTo(793, 501, duration=0.5) #move to comment box 6th
pyautogui.click(clicks=1, interval=0, button='left') #select comment box
pyautogui.typewrite('What about Byteball?', interval=0.1) #spam
pyautogui.moveTo(1223, 501, duration=0.5) #move to send
pyautogui.click(clicks=1, interval=0, button='left') #send button

pyautogui.moveTo(793, 455, duration=0.5) #move to comment box 7th
pyautogui.click(clicks=1, interval=0, button='left') #select comment box
pyautogui.typewrite('Time to buy elastos?', interval=0.1) #spam
pyautogui.moveTo(1223, 455, duration=0.5) #move to send
pyautogui.click(clicks=1, interval=0, button='left') #send button

pyautogui.moveTo(793, 413, duration=0.5) #move to comment box 8th
pyautogui.click(clicks=1, interval=0, button='left') #select comment box
pyautogui.typewrite('doge?', interval=0.1) #spam
pyautogui.moveTo(1223, 413, duration=0.5) #move to send
pyautogui.click(clicks=1, interval=0, button='left') #send button


while True :
	pyautogui.moveTo(793, 374, duration=0.5) #move to comment box loop
	pyautogui.click(clicks=1, interval=0, button='left') #select comment box
	pyautogui.typewrite('BCH is faster and cheaper', interval=0.1) #spam
	pyautogui.moveTo(1196, 394, duration=0.5) #move to send
	pyautogui.click(clicks=1, interval=0, button='left') #send button

	pyautogui.moveTo(793, 374, duration=0.5) #move to comment box loop
	pyautogui.click(clicks=1, interval=0, button='left') #select comment box
	pyautogui.typewrite('doge?', interval=0.1) #spam
	pyautogui.moveTo(1196, 394, duration=0.5) #move to send
	pyautogui.click(clicks=1, interval=0, button='left') #send button

	pyautogui.moveTo(793, 374, duration=0.5) #move to comment box loop
	pyautogui.click(clicks=1, interval=0, button='left') #select comment box
	pyautogui.typewrite('Time to buy elastos?', interval=0.1) #spam
	pyautogui.moveTo(1196, 394, duration=0.5) #move to send
	pyautogui.click(clicks=1, interval=0, button='left') #send button

	pyautogui.moveTo(793, 374, duration=0.5) #move to comment box loop
	pyautogui.click(clicks=1, interval=0, button='left') #select comment box
	pyautogui.typewrite('what about byteball?', interval=0.1) #spam
	pyautogui.moveTo(1196, 394, duration=0.5) #move to send
	pyautogui.click(clicks=1, interval=0, button='left') #send button

	pyautogui.moveTo(793, 374, duration=0.5) #move to comment box loop
	pyautogui.click(clicks=1, interval=0, button='left') #select comment box
	pyautogui.typewrite('doge to the moon', interval=0.1) #spam
	pyautogui.moveTo(1196, 394, duration=0.5) #move to send
	pyautogui.click(clicks=1, interval=0, button='left') #send button

	pyautogui.moveTo(793, 374, duration=0.5) #move to comment box loop
	pyautogui.click(clicks=1, interval=0, button='left') #select comment box
	pyautogui.typewrite('xrp army', interval=0.1) #spam
	pyautogui.moveTo(1196, 394, duration=0.5) #move to send
	pyautogui.click(clicks=1, interval=0, button='left') #send button

	pyautogui.moveTo(793, 374, duration=0.5) #move to comment box loop
	pyautogui.click(clicks=1, interval=0, button='left') #select comment box
	pyautogui.typewrite('Mysterium Coin, Good Investment?', interval=0.1) #spam
	pyautogui.moveTo(1196, 394, duration=0.5) #move to send
	pyautogui.click(clicks=1, interval=0, button='left') #send button

	pyautogui.moveTo(793, 374, duration=0.5) #move to comment box loop
	pyautogui.click(clicks=1, interval=0, button='left') #select comment box
	pyautogui.typewrite('wen lambo', interval=0.1) #spam
	pyautogui.moveTo(1196, 394, duration=0.5) #move to send
	pyautogui.click(clicks=1, interval=0, button='left') #send button