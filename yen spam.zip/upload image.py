import pyautogui

while True :

	pyautogui.moveTo(776, 237, duration=1.5) #move to post
	pyautogui.click(clicks=1, interval=0, button='left') #open post box
	pyautogui.moveTo(693, 496, duration=1.5) #move to type
	pyautogui.click(clicks=1, interval=0.1, button='right') #right click
	pyautogui.moveTo(749, 571, duration=1.5) #move to paste
	pyautogui.click(clicks=1, interval=0, button='left') #paste
	pyautogui.moveTo(1217, 434, duration=1.5) #move to send
	pyautogui.click(clicks=1, interval=0, button='left') #send button
